public class Patient {
    /**
     * This class is where the patients' info and vaccine info will come from. Constructors and getters / setters are
     * also used in order to gain any information that we need.
     */
    private String firstName;
    private String lastName;
    private String dateOfBirth;
    private CoronaVaccine vaccineRecord;

    public Patient(String firstName, String lastName, String dateOfBirth) {

        this.firstName = firstName;
        this.lastName = lastName;
        this.dateOfBirth = dateOfBirth;

    }

    //define public get/set
    public String getFirstName() {

        return firstName;
    }

    public void setFirstName(String firstName){

        this.firstName = firstName;
    }

    public String getLastName() {

        return lastName;
    }

    public void setLastName(String lastName) {

        this.lastName = lastName;
    }

    public String getDateOfBirth() {

        return dateOfBirth;
    }

    public void setDateOfBirth(String dateOfBirth) {

        this.dateOfBirth = dateOfBirth;
    }

    public CoronaVaccine getVaccineRecord() {

        return vaccineRecord;
    }

    public void setVaccineRecord(CoronaVaccine vaccineRecord) {

        this.vaccineRecord = vaccineRecord;
    }


    /**
     * Below is the 'behind the scenes' methods where once we give the program out input, the following will be
     * displayed as the output.
     */
    public String toString() {

        return "Patient{" +
                "First Name='" + firstName + '\'' +
                "Last Name='" + lastName + '\'' +
                "Date of Birth='" + dateOfBirth + "," + '\'' +
                "\nVaccine=" +
                vaccineRecord + '}';

    }

}
