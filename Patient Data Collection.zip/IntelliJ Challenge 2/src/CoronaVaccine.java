public class CoronaVaccine {

    /**
     * Below, we gain the information regarding the vaccine while using constructors and getters / setters just like in
     * the Patient class.
     *
     */

    private String nameVaccine;
    private String dateFirstShot;
    private String dateSecondShot;
    private String dateBooster;
    private String locationShot;


    public CoronaVaccine(String nameVaccine, String dateFirstShot, String dateSecondShot, String dateBooster, String locationShot) {

        this.nameVaccine = nameVaccine;
        this.dateFirstShot = dateFirstShot;
        this.dateSecondShot = dateSecondShot;
        this.dateBooster = dateBooster;
        this.locationShot = locationShot;

    }
    //public get/set
    public String getNameVaccine() {

        return nameVaccine;
    }

    public void setNameVaccine(String nameVaccine) {

        this.nameVaccine = nameVaccine;
    }

    public String getDateFirstShot() {

        return dateFirstShot;
    }

    public void setDateFirstShot(String dateFirstShot) {

        this.dateFirstShot = dateFirstShot;
    }

    public String getDateSecondShot() {

        return dateSecondShot;
    }

    public void setDateSecondShot(String dateSecondShot) {

        this.dateSecondShot = dateSecondShot;
    }

    public String getDateBooster() {

        return dateBooster;
    }

    public void setDateBooster(String dateBooster) {

        this.dateBooster = dateBooster;
    }

    public String getLocationShot() {

        return locationShot;
    }

    public void setLocationShot(String locationShot) {

        this.locationShot = locationShot;
    }

    /**
     * This method will be called in the Patient class so when aPatient is called in the Driver class, all the
     * information required will be there.
     *
     */
    public String toString() {

        return "Vaccine Record {" +
                "Name of vaccine='" + nameVaccine + '\'' +
                ", first shot='" + dateFirstShot + '\'' +
                ", second shot='" + dateSecondShot + '\'' +
                ", booster shot='" + dateBooster + '\'' +
                ", location of shot='" + locationShot + '}';


    }

}
