import java.util.Scanner;

/**
 * Jorge Morales ID: 6300116
 *
 * Title: IntelliJ Project 2
 * Semester: COP2210 - Fall 2022
 * Professor: Cristy Charters
 *
 * This programs demonstrates the use of constructors, getter and setter, as well as the use and initialization of
 * different classes. The main purpose of this program is to collect personal data as well as vaccination date from
 * three patients.
 */
public class Driver {
    /**
     * The main method below will allow use to get the objects from the other domain classes and transfer them here.
     * The process would repeat 3 times in order to display all 3 patients.
     *
     */
    public  static void main (String[] args) {

        Scanner scnr = new Scanner(System.in);

        Patient aPatient = createAPatient(scnr);
        CoronaVaccine aVaccineRecord1 = createAVaccineRecord(scnr);
        aPatient.setVaccineRecord(aVaccineRecord1);
        reportVaccinations(aPatient);

        Patient aPatient2 = createAPatient(scnr);
        CoronaVaccine aVaccineRecord2 = createAVaccineRecord(scnr);
        aPatient2.setVaccineRecord(aVaccineRecord2);
        reportVaccinations(aPatient2);

        Patient aPatient3 = createAPatient(scnr);
        CoronaVaccine aVaccineRecord3 = createAVaccineRecord(scnr);
        aPatient3.setVaccineRecord(aVaccineRecord3);
        reportVaccinations(aPatient3);

    }

    /**
     *  Below, we will define 3 methods: createPatient, createVaccine, and reportVaccine in order to input the patients personal info,
     *  the vaccine and the dates, and to display the information respectively.
     */

    public static Patient createAPatient(Scanner keyboard) {

        String firstName, lastName, dateOfBirth;

        System.out.println("Let's collect the patients data:\n");
        System.out.println("What is the patient's first name?");
        firstName = keyboard.nextLine();
        System.out.println("What is the patient's last name?");
        lastName = keyboard.nextLine();
        System.out.println("When was the patient born?");
        dateOfBirth = keyboard.nextLine();

        Patient aPatient = new Patient(firstName, lastName, dateOfBirth);

        return aPatient;
    }

    public static CoronaVaccine createAVaccineRecord(Scanner keyboard) {

        String nameVaccine, dateFirstShot, dateSecondShot, dateBooster, locationShot;

        System.out.println("Let's collect the vaccination data:\n");
        System.out.println("What is the name of the Corona Vaccine Manufacturer?");
        nameVaccine = keyboard.nextLine();
        System.out.println("What is the date of your 1st vaccine shot?");
        dateFirstShot = keyboard.nextLine();
        System.out.println("What is the date of your 2nd shot?");
        dateSecondShot = keyboard.nextLine();
        System.out.println("What is the date of your booster shot?");
        dateBooster = keyboard.nextLine();
        System.out.println("What is the location/site of your vaccines?");
        locationShot = keyboard.nextLine();

        return new CoronaVaccine(nameVaccine, dateFirstShot, dateSecondShot, dateBooster, locationShot);


    }

    public static void reportVaccinations(Patient aPatient) {

        System.out.println("This is the record for " + aPatient.getFirstName() + " " + aPatient.getLastName());
        System.out.println(aPatient);
    }




}
