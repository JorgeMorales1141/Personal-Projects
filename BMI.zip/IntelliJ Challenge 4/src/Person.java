public class Person {
    /**
     * Below, we are initializing the information of the person so we can do the necessary calculations.
     */
    private String lastName;
    private String firstName;
    private double heightInches;
    private double weightPounds;

    public Person() {

        lastName = "Smith";
        firstName = "John";
        heightInches = 68;
        weightPounds = 135.5;
    }

    /**
     * In the Person method, we set up the constructor for our information, followed by the appropriate
     * setters and getters. Followed by the ToString (which is displayed in the driver class.
     */
    public Person(String firstName, String lastName, double heightInches, double weightPounds) {

        this.firstName = firstName;
        this.lastName =lastName;
        this.heightInches = heightInches;
        this.weightPounds = weightPounds;

    }

    public String getFirstName() {

        return firstName;
    }

    public void setFirstName(String firstName) {

        this.firstName = firstName;
    }

    public String getLastName() {

        return lastName;
    }

    public void setLastName(String lastName) {

        this.lastName = lastName;
    }

    public double getHeightInches() {

        return heightInches;
    }

    public void setHeightInches(double heightInches) {

        this.heightInches = heightInches;
    }

    public double getWeightPounds() {

        return weightPounds;
    }

    public void setWeightPounds(double weightPounds) {

        this.weightPounds = weightPounds;
    }

    public String ToString() {

        return firstName + " " + lastName + " is " + heightInches + " inches tall and weighs " + weightPounds + " pounds.";
    }

    /**
     * Below, we have the optimum weight formula which is used if the person is considered not healthy.
     */
    public double recommendedWeight() {

        double optimumWeight = 0;

        optimumWeight = (int) ((25 * Math.pow(heightInches, 2)) / 703);

        return optimumWeight;
    }

    /**
     * Below, we calculate the BMI of the person using the height and weight we input as part
     * of the formula. With this we can determine if the person is healthy or not.
     */
    public double calcBMI() {

        double bmi = 0;

        bmi = (weightPounds / Math.pow(heightInches, 2)) * 703;

        return bmi;
    }

    /**
     * Below, we use if/else statements to determine the person's health. The result will be used in the
     * if/else statement in the driver class.
     */
    public String determineHealth(double aBMI) {

        String healthStatus = "";

        if (aBMI < 18.5) {

            System.out.println("\nUnderweight");
        }

        else if ((aBMI >= 18.5) && (aBMI < 25)) {

            System.out.println("\nHealthy");
        }

        else if ((aBMI >= 25) && (aBMI < 30)) {

            System.out.println("\nOverweight");
        }

        else if ((aBMI >= 30) && (aBMI < 39.9)) {

            System.out.println("\nObese");
        }

        else {

            System.out.println("\nExtremely Obese");
        }

        return healthStatus;
    }
}


