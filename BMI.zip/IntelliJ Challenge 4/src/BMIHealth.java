import java.util.Objects;
import java.util.Scanner;

/**
 * Jorge Morales   PID: 6300116
 * COP 2210   Fall-2022
 * Cristy Charters
 *
 * Description: This programs demonstrates the use of different class, method calling, and if/else statements.
 * The purpose of this program is to calculate the BMI of a person to determine whether that person
 * is healthy or not. In the main method, we are defining two methods: createAPerson and showBMI.
 *
 */

public class BMIHealth {

    public static void main(String[] args) {

        Person aPerson = createAPerson();
        showBMI(aPerson);

    }

    /**
     * In the createAPerson method, we are collecting the information of the person in question which includes the name,
     * height, and weight. aPerson will be defined in order to be called by method showBMI.
     */
    public static Person createAPerson(){

        Scanner keyboard = new Scanner(System.in);
        String firstName;
        String lastName;
        double height;
        double weight;

        System.out.println("What is your first name?");
        firstName = keyboard.nextLine();
        System.out.println("What is your last name?");
        lastName = keyboard.nextLine();
        System.out.println("How tall are you?");
        height = keyboard.nextDouble();
        keyboard.nextLine();
        System.out.println("How much do you weigh?");
        weight = keyboard.nextDouble();
        keyboard.nextLine();

        Person aPerson = new Person(firstName, lastName, height, weight);
        return aPerson;
    }

    /**
     * In showBMI, we are calling the objects from the Person class and outputting it here. This includes
     * the BMI and health status. We also use the if/else statement to determine whether the person is
     * considered healthy. If not, we call the recommendedWeight method to display the optimum weight.
     */
    public static void showBMI(Person aPerson) {


        System.out.println(aPerson.ToString());
        double BMI = (aPerson.calcBMI());
        aPerson.determineHealth(BMI);

        if (aPerson.determineHealth(BMI).equals("Your healthy.")) {
        }

        else {
            double optimumWeight = aPerson.recommendedWeight();
            System.out.println("The recommended weight is " + (int) optimumWeight + " pounds.");
        }

        
    }
}
